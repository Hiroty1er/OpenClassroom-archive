SELECT COUNT(*) AS "nombre total d'appartement au 1er trimestres"
FROM Vente_immobiliere
WHERE date BETWEEN "2020-01-01" AND "2020-07-01"